furnace.removeByInput(item('extraplanets:ceres', 6));
furnace.add(item('extraplanets:ceres', 6), item('nuclearcraft:ingot', 4));

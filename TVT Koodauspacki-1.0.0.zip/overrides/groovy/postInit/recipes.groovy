crafting.addShapeless(item("minecraft:flint"), [item("minecraft:gravel"),item("minecraft:gravel"),item("minecraft:gravel")]);

mods.gregtech.lateMaterialEvent {
	material("copper").addFlags("generate_gear")
	material("tin").addFlags("generate_gear")
}
